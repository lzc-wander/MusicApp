package com.example.administrator.localmusic1;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.util.List;

public class ServiceMy extends Service {
    private String path;
    private int position;
    private String PID;
    private List<Song> list;
    private int size;//歌曲总数
    private MediaPlayer player;
    private MusicApplication musicApplication;


    public ServiceMy() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
     //   list=MusicUtils.getMusicData(this);
        musicApplication=(MusicApplication)getApplication();

        list=musicApplication.getList();
        player=new MediaPlayer();
        size =list.size();
        Log.d("lujing",String.valueOf(size));
        Log.d("fuwu","Activity start");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {



        //  position=(Integer.parseInt(intent.getStringExtra("position")));
        PID=intent.getStringExtra("position");
       position=Integer.parseInt(PID);
        path=intent.getStringExtra("path");
       // Log.d("fuwu",list.get(position).singer);
       // path=list.get(position).path;
        if(player!=null){

            player.stop();
          //  player.release();
            init();
        }else{
            init();
        }

        return super.onStartCommand(intent, flags, startId);
    }
    public void init(){

        try{
            Log.d("fuwu","Music");

            player.reset();//播放之前将音频文件重置
            player.setDataSource(path);//指定音频文件的路径
//            //异步准备音频资源
            player.prepareAsync();
            player.setLooping(true);//单曲循环
            //调用mediaPlayer的监听方法，音频准备完毕会响应此方法
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {

                    mediaPlayer.start();//开始音频

                }
            });

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void onDestroy() {
        if(player.isPlaying()){
            player.stop();//停止播放
            player.release();//释放资源
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return new MyBinder();

    }

    public class MyBinder extends Binder{
        public void playMusic(){
            if(!player.isPlaying()){
                //开始播放
                player.start();

            }
        }
        public boolean isPlaying(){
            return player.isPlaying();
        }
        //暂停播放
        public void pauseMusic(){
            if (player.isPlaying()){
                player.pause();
            }
        }
        //重新播放
        public void resetMusic(){
            if(!player.isPlaying()){
                player.reset();

            }
        }
        //关闭播放器
        public void closeMedis(){
            if(player!=null){
                player.stop();
                player.release();

            }
        }

        //下一首
        public Bitmap nextMusic(){
                if(position<size-1){
                    position++;
                    path=list.get(position).path;


                }else if(position==size-1){
                    position=0;
                    path=list.get(position).path;
            }
            if(player.isPlaying()){
                player.stop();
               // player.isPlaying();
                init();

            }else {
                init();
            }
            Log.d("next",String.valueOf(position));
            return list.get(position).bitmap;
        }
        //上一首
        public Bitmap lastMusic(){
                if(position>0){
                    position--;
                    path=list.get(position).path;
                }else if(position==0){
                    position=list.size()-1;
                    path=list.get(position).path;
                }
            if(player.isPlaying()){
                player.stop();
                // player.isPlaying();
                init();

            }else{
                init();
            }
            return list.get(position).bitmap;
        }
        //获取歌曲长度
        public int getProgress(){

            return player.getDuration();
        }
        //获取播放的位置
        public int getPlayPosition(){
            int position=player.getCurrentPosition();
            Log.d("position",String.valueOf(position));
            return player.getCurrentPosition();

        }
        //播放指定的位置
        public void seekToPosition(int msec){

            if(!player.isPlaying()){
                player.start();
            }
            player.seekTo(msec);

        }
        public Bitmap getMap(int position){
            return list.get(position).bitmap;
        }
        public int bgFlag(int position){
            return list.get(position).flag;
        }
    }
}

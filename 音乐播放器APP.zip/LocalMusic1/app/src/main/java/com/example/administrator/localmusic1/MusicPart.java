package com.example.administrator.localmusic1;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;

import android.os.Message;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.administrator.localmusic1.util.BlurUtil;
import com.example.administrator.localmusic1.util.MargeImg;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class MusicPart extends AppCompatActivity implements Runnable {
    private ServiceMy.MyBinder myBinder;
    private String path;
    private int position;
    private String PID;
    private ImageButton SP;//播放或者暂停
    private ImageButton next;//下一首
    private ImageButton last;//上一首
    private Bitmap discBitmap;//黑胶唱片
    private Bitmap thumbBitmap;//专辑封面图
    private SeekBar seekBar;
    private List<Song> list = new ArrayList<>();
    private TextView start;
    private TextView stop;
    private static final int UPDATA_PROGRESS = 1;
    private Thread thread;
    private LinearLayout layout;
    private ImageView imgview;
    private TextView singname;
    private TextView songname;
    private ImageButton back;
    //用于判断没有专辑图片的歌曲，flag=1是没有专辑图片
    private MusicApplication musicApplication;
    Intent intent3;
    ObjectAnimator animator=new ObjectAnimator();
    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case UPDATA_PROGRESS:
                    updateProgress();

                    break;
                default:
                    break;
            }
        }
    };
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            myBinder = (ServiceMy.MyBinder) service;
            Log.d("服务", "服务回来");
            seekBar.setMax(myBinder.getProgress());
            //设置进度条的进度
            seekBar.setProgress(myBinder.getPlayPosition());
            setBack();//背景图的设置
            singname.setText(list.get(position).singer);
            songname.setText(list.get(position).songtitle);

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("服务", "活动开始");
        musicApplication=(MusicApplication)getApplication();
        setContentView(R.layout.activity_music_part);
        //列表
        list = MusicUtils.getMusicData(this);
        final Intent intent = getIntent();
        //获取BitMap类型
        //获取位置
        PID = intent.getStringExtra("position");
        position = Integer.parseInt(PID);
        //Bitmap和Drawble的转换
        discBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.play_page_disc);
        //专辑封面
        thumbBitmap = list.get(position).bitmap;
        //设置
        layout = (LinearLayout) findViewById(R.id.activity_music_part);
        //找到背景图
        imgview = (ImageView) findViewById(R.id.background);
        //layout.;
        Bitmap bm = MargeImg.mergeThumbnailBitmap(discBitmap, thumbBitmap);
        imgview.setImageBitmap(bm);

        // imgview.setImageBitmap(bgbm);
        path = intent.getStringExtra("path");
        intent3 = new Intent(MusicPart.this, ServiceMy.class);
        //开启服务


        intent3.putExtra("position", position + "");
        intent3.putExtra("path", path);

        startService(intent3);
        bindService(intent3, connection, BIND_AUTO_CREATE);//绑定服务
        run();
        //音乐时间变化
        start=(TextView) findViewById(R.id.start);
        stop=(TextView) findViewById(R.id.stop);
        int duration = list.get(position).duration;
        String time = MusicUtils.formatTime(duration);
        stop.setText(time);


        //歌曲名字和歌手的变化
        singname=(TextView) findViewById(R.id.singerName);
        songname=(TextView) findViewById(R.id.songName) ;

        //返回按钮
        back=(ImageButton) findViewById(R.id.backButton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              finish();
            }
        });
        seekBar = (SeekBar) findViewById(R.id.seekbar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //进度条改变
                if (fromUser) {
                    Log.d("fuwu", "进度条变化");
                    //音乐的进度变化
                    myBinder.seekToPosition(progress);
                    String time = MusicUtils.formatTime(progress);
                    start.setText(time);
                    SP.setImageResource(R.drawable.ic_global_pause);

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //开始触摸进度条
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //停止触摸进度条
            }
        });

        SP = (ImageButton) findViewById(R.id.SPButton);
        SP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myBinder.isPlaying()) {
                    //暂停
                    myBinder.pauseMusic();
                    SP.setImageResource(R.drawable.ic_global_play);
                    Log.d("State","zanting");
                    animator.pause();
                } else {
                    myBinder.playMusic();
                    SP.setImageResource(R.drawable.ic_global_pause);
                    Log.d("State","bofang");
                    animator.resume();
                }


            }
        });
        //下一首
        next = (ImageButton) findViewById(R.id.NextButton);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                thumbBitmap=myBinder.nextMusic();
                // stop.setText(formatTime(myBinder.getProgress()));
                int mm=musicApplication.getList().size();
                list=musicApplication.getList();
                Log.d("partSize",String.valueOf(mm));
                Log.d("partSize",String.valueOf(mm));
                int duration = list.get(position).duration;
                String time = MusicUtils.formatTime(duration);
                stop.setText(time);
                //歌手名字

                Bitmap bm = MargeImg.mergeThumbnailBitmap(discBitmap, thumbBitmap);
                SP.setImageResource(R.drawable.ic_global_pause);
                imgview.setImageBitmap(bm);
                // RoundImg();
                animator.start();
                // int  flag=myBinder.bgFlag(position);
                Log.d("nextSize",String.valueOf(list.size()));
                if(position<list.size()-1){
                    position++;
                    setBack();


                }else if(position==list.size()-1){
                    position=0;
                    setBack();
                }
                singname.setText(list.get(position).singer);
                songname.setText(list.get(position).songtitle);
            }

        });
        //上一首
        last = (ImageButton) findViewById(R.id.lastButton);
        last.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                thumbBitmap=myBinder.lastMusic();
                musicApplication.setList(list);
                list=musicApplication.getList();
                int duration = list.get(position).duration;
                String time = MusicUtils.formatTime(duration);
                stop.setText(time);
                //歌手名字

                Bitmap bm = MargeImg.mergeThumbnailBitmap(discBitmap, thumbBitmap);
                imgview.setImageBitmap(bm);
                SP.setImageResource(R.drawable.ic_global_pause);
                // RoundImg();
                animator.start();
                if(position>0){
                    position--;
                    setBack();
                }else if(position==0){
                    Log.d("nextSize",String.valueOf(list.size()));
                    position=list.size()-1;
                    setBack();
                }
                singname.setText(list.get(position).singer);
                songname.setText(list.get(position).songtitle);
                // int flag=myBinder.bgFlag(position);

            }
        });

        //动画旋转：
        RoundImg();
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//
//
//            }
//        }).start();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.

    }
    public void RoundImg(){
        animator = ObjectAnimator.ofFloat(imgview, "rotation", 0f, 360.0f);
        //动画的类型在Android中有四种alpha透明度、rotation旋转、scale缩放、translation平移
        animator.setDuration(10000);
        animator.setInterpolator(new LinearInterpolator());//匀速
        animator.setRepeatCount(-1);//设置动画重复次数（-1代表一直转）
        animator.setRepeatMode(ValueAnimator.RESTART);//动画重复模式
        animator.start();

    }

    private void updateProgress() {
        int currenPostion = myBinder.getPlayPosition();
        String time = MusicUtils.formatTime(currenPostion);
        start.setText(time);
        Log.d("进程条", String.valueOf(currenPostion));
        seekBar.setMax(myBinder.getProgress());
        //设置进度条的进度
        seekBar.setProgress(myBinder.getPlayPosition());
        seekBar.setProgress(currenPostion);

        //设置进度的进程
        //使用Handler每500毫秒更新一次进度条
        handler.sendEmptyMessageDelayed(UPDATA_PROGRESS, 500);

    }

    protected void onResume() {
        super.onResume();
        //进入到界面后开始更新进度条
        if (myBinder != null) {
            handler.removeCallbacksAndMessages(null);
            handler.sendEmptyMessage(UPDATA_PROGRESS);
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        //退出应用后与service解除绑定
        Log.d("MusicPart","onDestory");
        //stopService(intent3);
        unbindService(connection);
    }

    @Override
    protected void onStop() {
        super.onStop();
        //停止更新进度条的进度

        handler.removeCallbacksAndMessages(null);

    }

    public void run() {
        Message message = new Message();
        message.what = UPDATA_PROGRESS;
        handler.sendEmptyMessageDelayed(UPDATA_PROGRESS, 500);
    }
    public void setBack(){
        LinearLayout linearLayout=(LinearLayout) findViewById(R.id.activity_music_part);


        int  flag=myBinder.bgFlag(position);
        Log.d("flag",String.valueOf(flag));
        if(flag==0){//有专辑图片
            Log.d("专辑",String.valueOf(flag));
            Bitmap bgm= BlurUtil.doBlur(thumbBitmap,10,5);
            linearLayout.setBackground(new BitmapDrawable(bgm));
        }else if(flag==1){
            Log.d("专辑",String.valueOf(flag));
            Bitmap    bmp = BitmapFactory.decodeResource(getResources(),R.drawable.newback );//用于drawble与Bitmap资源相互切换
            Bitmap bgm=BlurUtil.doBlur(bmp,10,5);
            linearLayout.setBackground(new BitmapDrawable(bgm));

        }


//    Bitmap img = BitmapFactory.decodeFile(thumbBitmap);
//    Drawable drawable=Drawable.createFromPath( thumbBitmap);
    }
    ///////////////获取歌曲时常///////////////////////
    private String formatTime(int length) {
        Date date = new Date(length);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("mm:ss");
        String TotalTime = simpleDateFormat.format(date);

        return TotalTime;

    }


}
package com.example.administrator.localmusic1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

/**
 * Created by Administrator on 2018/11/17 0017.
 */

public class MyDatabaseHelper extends SQLiteOpenHelper {
    public static final String CREATE_USER="create table user("+
            "id integer primary key autoincrement,"
            +"name text,"
            +"phone text,"
            +"password text)";
    //    primary key主键，autoincrement自动增长

    private Context mcontext;
    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory,int version) {
        super(context,name,factory,version);
        mcontext=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER);//把建表语句定为常量，db.execSQL(CREATE_BOOK);//执行建表

        Toast.makeText(mcontext,"Create Succeed",Toast.LENGTH_LONG).show();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}

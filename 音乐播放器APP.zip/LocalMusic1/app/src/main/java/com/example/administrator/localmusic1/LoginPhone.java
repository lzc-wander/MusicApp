package com.example.administrator.localmusic1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class LoginPhone extends AppCompatActivity {
    private EditText editPhone;
    private EditText editPass;
    private Button button;
    private String phone;
    private String password;
    private String name;
    private MyDatabaseHelper helper;
    String phoneS;
    String nameS;
    String passS;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityCollector.addActivity(this);
        setContentView(R.layout.activity_login_phone);
//        editName=(EditText)findViewById(R.id.name)
        editPhone=(EditText) findViewById(R.id.phoneedit);
        editPass=(EditText) findViewById(R.id.password);
        button=(Button) findViewById(R.id.loginbutton);
        //name=editPhone.getText().toString();
        phone=editPhone.getText().toString();
        password=editPass.getText().toString();
        progressBar=(ProgressBar) findViewById(R.id.progress);
        helper=new MyDatabaseHelper(this,"MusicUser.db",null,1);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                SQLiteDatabase db=helper.getWritableDatabase();
                //查询数据
                Cursor cursor=db.rawQuery("select * from user ",null);

                if(cursor.moveToFirst()){
                    do{
                        //遍历对象
                         nameS=cursor.getString(cursor.getColumnIndex("name"));
                         phoneS=cursor.getString(cursor.getColumnIndex("phone"));
                         passS=cursor.getString(cursor.getColumnIndex("password"));
                       Log.d("name",nameS);
                        Log.d("phone",phoneS);
                        Log.d("passS",passS);
                        Log.d("True","查询数据");
                    }while (cursor.moveToNext());
                }
                cursor.close();
                //根据用户名或者手机号来登录
                if((editPhone.getText().toString().equals(phoneS)&&editPass.getText().toString().equals(passS))||
                        (editPhone.getText().toString().equals(nameS)&&editPass.getText().toString().equals(passS))){

                    Toast.makeText(LoginPhone.this,"登录成功",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(LoginPhone.this,MainActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(LoginPhone.this,"账号不存在或者密码不对",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityCollector.removeActivity(this);
        ActivityCollector.finishAll();
    }
}

package com.example.administrator.localmusic1;

import android.app.Application;
import android.media.MediaPlayer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2018/12/3 0003.
 */

public class MusicApplication extends Application {
    private List<Song> list=new ArrayList<>();


    @Override
    public void onCreate() {
        super.onCreate();
        setList(list);
    }

    public void setList(List<Song> list) {
        this.list = list;
    }

    public List<Song> getList() {
        return list;
    }


}

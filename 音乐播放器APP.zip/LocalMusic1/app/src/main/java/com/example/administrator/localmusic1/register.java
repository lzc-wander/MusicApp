package com.example.administrator.localmusic1;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class register extends AppCompatActivity {
    private EditText nameEdit;
    private EditText phoneEdit;
    private EditText passEdit;
    private Button button;
    String name;
    String phone;
    String password;
    private MyDatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityCollector.addActivity(this);
        setContentView(R.layout.activity_register);
        helper=new MyDatabaseHelper(this,"MusicUser.db",null,1);
        nameEdit=(EditText) findViewById(R.id.Rname);
        phoneEdit=(EditText)findViewById(R.id.Rphone);
        passEdit=(EditText)findViewById(R.id.Rpassword);
        button=(Button) findViewById(R.id.register);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                helper.getWritableDatabase();
                //先建立数据库
                SQLiteDatabase db=  helper.getWritableDatabase();
                name=nameEdit.getText().toString();
                phone=phoneEdit.getText().toString();
                password=passEdit.getText().toString();
                ContentValues values=new ContentValues();
                values.put("name",name);
                values.put("phone",phone);
                values.put("password",password);
                //上传数据
                db.insert("user",null,values);
                values.clear();
                //跳转到登录界面
                Intent intent=new Intent(register.this,LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityCollector.removeActivity(this);
        ActivityCollector.finishAll();
    }
}

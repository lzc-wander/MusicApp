package com.example.administrator.localmusic1;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/11/22 0022.
 */

public class Song implements Serializable{
    //歌手名字
    public String singer;
   //歌曲名字
    public String songtitle;
    //歌曲地址
    public String path;
    //歌曲长度
    public int duration;
    //歌曲大小
    public long size;
    //图片
    public ImageView coverimg;

    public  String album_id;
    //专辑海报
    public Bitmap bitmap;
    //判断专辑图片
    public int flag;
}

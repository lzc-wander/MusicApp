package com.example.administrator.localmusic1;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private ListView mListView;
    private List<Song> list;
    private MyAdapter adapter;
    private Context context;
    private MusicApplication musicApplication;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityCollector.addActivity(this);
        musicApplication=(MusicApplication) getApplication();
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        //去除状态栏
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            },1);
        }else{
            initView();
        }


//        initView();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityCollector.removeActivity(this);
        ActivityCollector.finishAll();
    }

    /**
     * 初始化view
     */

    private void initView() {
        mListView = (ListView) findViewById(R.id.main_listview);
        list = new ArrayList<>();
        //把扫描到的音乐赋值给list
        context=this.context;
        list = MusicUtils.getMusicData(this);
        musicApplication.setList(list);
        String size=String.valueOf(musicApplication.getList().size());
        Log.d("SIZE",size);
        adapter = new MyAdapter(this,list);
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                play(list.get(position).path);

                Toast.makeText(MainActivity.this,list.get(position).songtitle,Toast.LENGTH_LONG).show();

                int flag=0;
                //Drawable.ConstantState drawableCs = resources.getDrawable(R.drawable.cd_bg).getConstantState();
                if( list.get(position).flag!=flag)
                {
                    //更换背景图
                    Resources resources = MainActivity.this.getResources();
                    Drawable drawable = resources.getDrawable(R.drawable.default_album);
                    //Drawable 转 Bitmap
                    BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;

                    list.get(position).bitmap=Bitmap.createScaledBitmap(bitmapDrawable.getBitmap(), 150, 150, true);
                }
                Intent intent=new Intent(MainActivity.this, MusicPart.class);
                //传递列表
                intent.putExtra("img",list.get(position).bitmap);
                String path=list.get(position).path;
                intent.putExtra("path",path);
                String PID=String.valueOf(position);
                intent.putExtra("position",PID);
                startActivity(intent);

            }


        });


        //长按删除音乐功能
        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                Song song=list.get(position);
                final String abc = (String) song.path;
                String na = (String) song.songtitle;
                final AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
                ab.setTitle("是否删除该歌曲 ==>"+na);
                ab.setMessage("删除该歌曲，");
                ab.setPositiveButton("删除", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.d("size",String.valueOf(list.size()));
                        File mf = new File(abc);
                        if(list.remove(position)!=null){
                            Log.d("size",String.valueOf(list.size()));
                            mf.delete();
                            adapter.notifyDataSetChanged();//更新列表
                            musicApplication.setList(list);
                            int mm=musicApplication.getList().size();
                            Log.d("mm",String.valueOf(mm));
                            Toast.makeText(MainActivity.this, "OK成功删除", Toast.LENGTH_LONG).show();
                        }else {
                            Toast.makeText(MainActivity.this, "该文件不存在", Toast.LENGTH_LONG).show();
                        }
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ab.create();
                ab.show();



                return true;
            }
        });
    }
    public void onRequestPermissionsResult(int requestCode ,String[] permissions,int[] grantResults){
        switch(requestCode){
            case 1:
                if(grantResults.length>0&& grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    initView();
                }else{
                    Toast.makeText(this,"拒绝权限将无法使用该程序，",Toast.LENGTH_LONG).show();
                    finish();
                }
                break;
            default:
        }
    }

}


package com.example.administrator.localmusic1;

import android.content.ContentUris;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2018/11/22 0022.
 */

public class MusicUtils {
    /**
     * 扫描系统里面的音频文件，返回一个list集合
     */
    public static int flag;
    public static List<Song> getMusicData(Context context) {
        List<Song> list = new ArrayList<Song>();

        // 媒体库查询语句（写一个工具类MusicUtils）
        Cursor cursor = context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null,
                null, MediaStore.Audio.AudioColumns.IS_MUSIC);
        //第一个参数：_uri代表要查询的数据库名称加上表的名称:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI获取所有歌的信息
        //第二个参数：   Prjs：这个参数代表要从表中选择的列，用一个String数组来表示
        //第三个参数  Selections：相当于SQL语句中的where子句，就是代表你的查询条件。null表示默认全部
        //第四歌参数   selectArgs：这个参数是说你的Selections里有？这个符号是，这里可以以实际值代替这个问号。如果Selections这个没有？的话，那么这个String数组可以为null。
        //第五个参数     Order：说明查询结果按什么来排序。
        if (cursor != null) {
            while (cursor.moveToNext()) {//下一行
                Song song = new Song();
                //音乐id
                long ID = cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media._ID));
                //歌曲专辑名id
                long albumId = cursor.getInt(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID));
                //歌曲的名称
                song.songtitle = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                //歌手名
                song.singer = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                //歌曲文件的全路径
                song.path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
                //歌曲的总播放时长
                song.duration = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                //歌曲文件的大小
                song.size = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE));
                //歌曲的专辑名
                song.album_id=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
                //歌曲的专辑海报
                song.bitmap=getMusicBitemp(context, ID, albumId);
                song.flag=flag;
                Log.d("Songde",String.valueOf(song.flag));

                if (song.size > 1000 * 800) {
                    // 注释部分是切割标题，分离出歌曲名和歌手 （本地媒体库读取的歌曲信息不规范）
                    if (song.songtitle.contains("-")) {//
                        //public boolean contains(CharSequence s) 当且仅当此字符串包含指定的 char 值序列时，返回 true。
                        String[] str = song.songtitle.split("-");//切割字符串组，以"-"为依据
                        song.singer = str[0];
                        song.songtitle = str[1];
                    }
                    list.add(song);
                }
            }
            // 释放资源
            cursor.close();
        }

        return list;
    }
    private static final Uri sArtworkUri = Uri.parse("content://media/external/audio/albumart");

    public static Bitmap getMusicBitemp(Context context, long songid, long albumid) {
        Bitmap bm = null;
// 专辑id和歌曲id小于0说明没有专辑、歌曲，并抛出异常
        if (albumid < 0 && songid < 0) {
            throw new IllegalArgumentException("Must specify an album or a song id");
        }
        try {
            if (albumid < 0) {
                //获取专辑海报的uri
                Uri uri = Uri.parse("content://media/external/audio/media/"
                        + songid + "/albumart");
                ParcelFileDescriptor pfd = context.getContentResolver()
                        .openFileDescriptor(uri, "r");
                if (pfd != null) {
                    FileDescriptor fd = pfd.getFileDescriptor();
                    bm = BitmapFactory.decodeFileDescriptor(fd);
                }
            } else {
                Uri uri = ContentUris.withAppendedId(sArtworkUri, albumid);
                ParcelFileDescriptor pfd = context.getContentResolver()
                        .openFileDescriptor(uri, "r");

                if (pfd != null) {
                    FileDescriptor fd = pfd.getFileDescriptor();

                    bm = BitmapFactory.decodeFileDescriptor(fd);


                } else {
                    return null;
                }
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
//如果获取的bitmap为空，则返回一个默认的bitmap
  if (bm == null) {
            Resources resources = context.getResources();
            Drawable drawable = resources.getDrawable(R.drawable.cd_bg);//赋予一个黑胶唱片的布局
            //Drawable 转 Bitmap
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            bm = bitmapDrawable.getBitmap();

            flag=1;
        }else {
        flag=0;
  }

        return Bitmap.createScaledBitmap(bm, 150, 150, true);
        //从当前存在的位图，按一定的比例创建一个新的位图。bm是源位图
    }

    /**
     * 定义一个方法用来格式化获取到的时间
     */
    public int returnflag(){
        return flag;
    }
    public static String formatTime(int time) {//静态方法
        if (time / 1000 % 60 < 10) {
            return time / 1000 / 60 + ":0" + time / 1000 % 60;

        } else {
            return time / 1000 / 60 + ":" + time / 1000 % 60;
        }

    }
}
